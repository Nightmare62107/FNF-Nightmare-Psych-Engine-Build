Put your hit sounds here!

To add your hit sound to the list, make a list.txt file on this folder and add your sound name, if you want to add multiple sounds, do it like this:

My Sound 1
My Sound 2
My Sound 3